/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package floatingpointsum;

/**
 *
 * @author x00139120
 */
public class FP_Equations {
    
}
