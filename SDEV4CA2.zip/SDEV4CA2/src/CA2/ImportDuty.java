/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CA2;

/**
 *
 * @author x00139120
 */
public interface ImportDuty {
    
    public static final double OSAKA_RATE = .10;
    public static final double OSAKA_UNLOADING_FEE = 100;
    public static final double TOKYO_RATE = .15;
    public static final double TOKYO_UNLOADING_FEE = 150;
    public static final double VAT = .23;
    public static final double BROKER_FEE = 120;
    
}
